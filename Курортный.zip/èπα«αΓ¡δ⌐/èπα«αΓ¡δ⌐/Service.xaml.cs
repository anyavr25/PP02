﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Курортный
{
    /// <summary>
    /// Логика взаимодействия для Service.xaml
    /// </summary>
    public partial class Service : Window
    {
        DispatcherTimer timers;
        public Service()
        {
            InitializeComponent();
            HistoryEntrLB.ItemsSource = App.DB.Client.ToList();
            serviceLB.ItemsSource = App.DB.Service.ToList();
            //Начало таймера, данные берутся из класса
            TimeSpan timer = TimeSpan.FromSeconds(allTime.Seconds);
            timerTxt.Text = timer.ToString(@"mm\:ss");
            timers = new DispatcherTimer();
            timers.Interval = TimeSpan.FromSeconds(1);
            timers.Tick += Timer_Tick;
            //начало тамймера
            timers.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            //если сеанс истечет
            if (allTime.Seconds <= 0)
            {
                //таймер останавливается
                timers.Stop();
                //таймер вновь перезагружается
                allTime.Refresh();
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }
            if (allTime.Seconds == 60)
            {
                allTime.MessageBoxic();
            }
            allTime.Seconds = allTime.Seconds - 1;
            TimeSpan time = TimeSpan.FromSeconds(allTime.Seconds);
            timerTxt.Text = time.ToString(@"mm\:ss");
        }

        private void Look_Click(object sender, RoutedEventArgs e)
        {
            //открытие окна добавление клиентов
            addClient add = new addClient();
            add.Show();
        }

        private void backBtn_Click(object sender, RoutedEventArgs e)
        {
            //закрытие данного окна и переход к окну авторизации
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        private void addService_Click(object sender, RoutedEventArgs e)
        {
            //окно добавление сервиса
            addService add = new addService();
            add.Show();
        }
    }
}
