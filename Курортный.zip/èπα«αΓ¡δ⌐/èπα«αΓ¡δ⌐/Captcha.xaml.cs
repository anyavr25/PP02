﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Курортный
{
    /// <summary>
    /// Логика взаимодействия для Captcha.xaml
    /// </summary>
    public partial class Captcha : Window
    {
        string check;
        public Captcha()
        {
            
            InitializeComponent();
            //при запуске данного окна ищспользуется метод
            check = GenerateText();
            //изображение берётся из класса
            captchaImage.Source = CaptGen.GenCap(200, 100, check);
        }
        //Метод для генерации текста капчи
        string GenerateText()
        {
            string captha = "";
            Random rd = new Random();
            string Alphafit = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
            string cifr = "123456789";
            string specSym = "!@#$%^&*";
            //с помощью Random строчные буквы, символы, числа
            //генерируются абсолютно по-разному
            string[] capt = { Alphafit, cifr, specSym };
            while (captha.Length != 4)
            {
                int n = rd.Next(0, 3);
                int m = rd.Next(0, capt[n].Length);
                captha = captha + capt[n][m];
            }
            //вовзрат сгенерированного текста
            return captha;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //обновление капчи
            check = GenerateText();
            captchaImage.Source = CaptGen.GenCap(200, 100, check);
        }
        DispatcherTimer timer = new DispatcherTimer();
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //если текст капчи равен введённому, окно капчи закрывается
            if (check == captchTxt.Text)
            {
                this.DialogResult = true;
                this.Close();
                return;
            }
            //если ввод неправильный - сообщениеоб ошибке и блокировка
            //ввода капчи с помощью таймера
            MessageBox.Show("Каптча введена не правильно! Доступ ограничен на 10 сек",
                "Внимание", MessageBoxButton.OK, MessageBoxImage.Stop);
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            s = 10;
            timer.Start();
            //кнопка не видна, если капча заблокирована
            OkBtn.IsEnabled = false;
        }
        int s = 0;
        private void Timer_Tick(object sender, EventArgs e)
        {
            if (s <= 0)
            {
                OkBtn.IsEnabled = true;
                timer.Stop();
                Button_Click(null, null);
            }
            s--;
        }
    }
}
