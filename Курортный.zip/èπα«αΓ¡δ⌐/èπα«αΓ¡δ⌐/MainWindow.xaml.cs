﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Курортный.Entities;


namespace Курортный
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        bool capt = false;
        private void Vxod_Click(object sender, RoutedEventArgs e)
        {
            //если переменна capt истина, открывается окно с капчей
            if (capt)
            {
                Captcha captcha = new Captcha();
                captcha.ShowDialog();
                //если каптча была верна, окно с капчей закрывается
                if (captcha.DialogResult == true)
                    capt = false;
            }
            foreach (var us in App.DB.Employee)
            {
                Employee employee = App.DB.Employee.FirstOrDefault();
                if (loginTct.Text == us.login)
                {
                    Hostory_entry entry = new Hostory_entry();
                    if (Passwords.Password == us.password)
                    {
                        //если вход успешен, в БД заносится последний вход
                        employee.last_entry = DateTime.Now;
                        //В бд заносится тип входа
                        employee.type_entry = "Успешно";
                        DateTime now = DateTime.Now;
                        DateTime dateExit = (DateTime)us.last_entry;
                        //если разница текущей даты и даты выхода меньше 3 минут
                        //вход заблокирован
                        if (now - dateExit <= TimeSpan.FromMinutes(3))
                        {
                            MessageBox.Show($"Вход может быть осуществлён только через:  " +
                                $"{Math.Round((TimeSpan.FromMinutes(3) - (DateTime.Now - dateExit)).TotalSeconds, 2)} секунд");
                            return;
                        }
                        //Открытие окна в зависимости от роли
                        if (us.id_role == 1)
                        {
                            HistoryEntry historyEntry = new HistoryEntry();
                            historyEntry.Show();
                        }
                        else if (us.id_role == 2)
                        {
                            
                        }
                        else if (us.id_role == 3)
                        {
                            Service service = new Service();
                            service.Show();
                        }
                    }
                    App.DB.SaveChanges();
                }
                else
                {
                    //при неуспешном входе информация об этом заносится в БД
                    employee.type_entry = "Неуспешно";
                    MessageBox.Show("Неверно введены данные");
                    App.DB.SaveChanges();
                }
                //открытие капчи
                capt = true;
                return;
            }
        }

        bool IsHidden = true;

        private void Look_Click(object sender, RoutedEventArgs e)
        {
            //просмотр пароля
            if (IsHidden)
            {
                Passwords.Visibility = Visibility.Visible;
                PasswordT.Text = Passwords.Password;
                IsHidden = false;
                return;
            }
            Passwords.Visibility = Visibility.Hidden;
            Passwords.Password = PasswordT.Text;
            IsHidden = true;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
