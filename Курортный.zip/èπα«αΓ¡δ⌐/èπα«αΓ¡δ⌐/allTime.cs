﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Курортный
{
    public class allTime
    {
        public static int Seconds { get; set; } = 120;
        public static void Refresh()
        {
            Seconds = 480;
        }
        public static void MessageBoxic()
        {
            MessageBox.Show("Внимание до конца сеанса осталась 1 минута", "Время сеанса", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }
}
